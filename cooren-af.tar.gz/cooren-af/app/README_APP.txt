This directory holds the appliance application (AF0 baseline).
The gate engine, six gate types, audit chain, and CSP client are installed here
at package time. This distribution ships the installer, ceremony docs, and the
enrollment/CSP client. Genesis mints your root and identity on first boot.
