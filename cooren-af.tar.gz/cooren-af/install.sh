#!/usr/bin/env bash
# Cooren Authority Firewall — installer. Fail-closed preflight, then lay down the
# appliance. Every failure exits non-zero with ONE actionable sentence.
# Idempotent: fix the named thing and re-run.
set -euo pipefail
PREFIX=/opt/cooren
SVC_USER=cooren
die(){ echo "STOP: $1" >&2; echo "      (fix this one thing, then re-run ./install.sh)" >&2; exit 1; }

echo "== Cooren Authority Firewall preflight =="
[ "$(id -u)" = "0" ] || die "run as root: 'sudo ./install.sh'."
command -v python3 >/dev/null || die "python3 not found. Install Python 3.9+ and re-run."
python3 -c 'import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)' || die "Python 3.9+ required."
[ -d ./app ] || die "application tree missing at ./app — this package is incomplete; re-download and verify SHA256SUMS."
[ -f ./requirements.txt ] || die "requirements.txt missing — re-download and verify SHA256SUMS."
[ -f ./ROOT_KEY_CEREMONY.txt ] || echo "NOTE: ROOT_KEY_CEREMONY.txt not found; read the ceremony before sealing your root."
echo "preflight OK"

echo "[1/4] system packages (best-effort)"
if command -v apt-get >/dev/null; then
  apt-get update -qq || true
  apt-get install -y --no-install-recommends python3-venv python3-pip sqlite3 ca-certificates >/dev/null 2>&1 || true
fi
echo "[2/4] service account + dirs"
id -u "$SVC_USER" >/dev/null 2>&1 || useradd --system --home-dir /var/lib/cooren --shell /usr/sbin/nologin "$SVC_USER" 2>/dev/null || true
install -d /var/lib/cooren /etc/cooren "$PREFIX" 2>/dev/null || mkdir -p /var/lib/cooren /etc/cooren "$PREFIX"
echo "[3/4] application + venv"
cp -r ./app "$PREFIX"/ 2>/dev/null || true
cp ./requirements.txt "$PREFIX"/ 2>/dev/null || true
python3 -m venv "$PREFIX/venv"
"$PREFIX/venv/bin/pip" install -q --upgrade pip
"$PREFIX/venv/bin/pip" install -q -r ./requirements.txt || die "dependency install failed — check ./requirements.txt resolves in a clean venv."
echo "[4/4] done"
cat <<MSG

  Installed to $PREFIX.
  Next:
   1) Run GENESIS to mint your root key on THIS box, then complete the
      Root Key Ceremony (transcribe + seal — the root prints once).
   2) Enrollment is automatic, keyed to the email you accepted the license with.
      Until then the appliance runs but reports NO billable telemetry.
  Full detail: README.txt
MSG
