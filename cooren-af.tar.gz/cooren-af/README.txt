COOREN AUTHORITY FIREWALL — appliance package
=============================================

WHAT THIS IS
  A single-tenant, default-off authorization gate. It runs on your own hardware.
  No license fee, no card to start. You pay $0.03 only when a human key opens a
  gate. Your keys, your root, your data stay on this box.

PREREQUISITES  (install.sh checks these and STOPS with a clear message if unmet)
  1. A Linux host you control (Debian/Ubuntu shown; any host that runs the
     container works), root/sudo.
  2. Python 3.9+ and the ability to create a virtualenv.
  3. Network egress to your Cooren collector over the Cooren Signal Protocol.
  4. The email address you accepted the license with. Enrollment is keyed to it.

INSTALL
  sudo ./install.sh

FIRST BOOT — in order, do not skip:
  A. GENESIS runs. Your appliance mints its ROOT key and its CSP identity on THIS
     box. The root key prints ONCE. Follow the Root Key Ceremony: transcribe it by
     hand, verify, seal it. It CANNOT be recovered. Do not photograph or copy it.
  B. ENROLLMENT is automatic, keyed to the email you accepted with. Until your
     acceptance is on record and enrollment completes, the appliance RUNS but
     reports NO billable or anchored telemetry.

IF SOMETHING FAILS
  install.sh fails closed with a one-line reason. Fix that one thing and re-run;
  it is idempotent. Do not improvise around a failed check. If a check is wrong for
  your environment, that is a packaging bug: contact@mcleodinteractivegroup.com.

WHAT LEAVES THIS BOX (ever):  endpoint id, gate counts, gate type, origin class,
  audit chain-head hashes, acting-key fingerprints.
WHAT NEVER LEAVES:  your keys, your sealed root, your data, gate payloads.

© 2026 McLeod Interactive Group LLC. Licensed under the Apache License, Version 2.0.
Hold Fast · Find A Way · Shine Brightly
